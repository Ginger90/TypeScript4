"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var input = document.getElementById('input');
var addBtn = document.getElementById('btn');
var lista = document.getElementById('lista');
var errore = document.getElementById('errore');
var elenco = [];
function printData() {
    fetch('http://localhost:3000/todo')
        .then((response) => {
        return response.json();
    }).then((data => {
        elenco = data;
        if (elenco.length > 0) {
            elenco.map(function (item) {
                lista.innerHTML += `<li><button type="button"class="btn btn-danger ms-1" onClick="elimina(${item.id})">X</button> ${item.task}</li> `;
            });
        }
    }));
}
printData();
addBtn.addEventListener('click', function controlla() {
    if ((input === null || input === void 0 ? void 0 : input.value) != '') {
        var data = {
            task: input === null || input === void 0 ? void 0 : input.value,
        };
        addData(data);
    }
    else {
        errore.innerHTML = 'Compila bene il campo assegnato!';
        return;
    }
});
// per aggiungere un elemento nel JSON
function addData(data) {
    return __awaiter(this, void 0, void 0, function* () {
        let response = yield fetch('http://localhost:3000/todo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            body: JSON.stringify(data),
        });
    });
}
function elimina(item) {
    return __awaiter(this, void 0, void 0, function* () {
        var answer = window.confirm("Sei sicuro?");
        if (answer) {
            try {
                let response = yield fetch(`http://localhost:3000/todo/${item}`, {
                    method: "DELETE",
                });
            }
            catch (err) {
            }
        }
    });
}
