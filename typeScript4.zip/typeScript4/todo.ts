var input = document.getElementById('input') as HTMLInputElement | null;
var addBtn = document.getElementById('btn') as HTMLElement;
var lista = document.getElementById('lista') as HTMLElement;
var errore = document.getElementById('errore') as HTMLElement;
var elenco: string[] = [];



function printData() {
    fetch('http://localhost:3000/todo')
        .then((response) => {
            return response.json();
        }).then((data => {
            elenco = data;
            if (elenco.length > 0) {
                elenco.map(function (item: any): any {
                    lista.innerHTML += `<li><button type="button"class="btn btn-danger ms-1" onClick="elimina(${item.id})">X</button> ${item.task}</li> `;

                })
            }
        }))
}
printData();

addBtn.addEventListener('click', function controlla() {
    if (input?.value != '') {
        var data: any = {
            task: input?.value,
        };
        addData(data);
    } else {
        errore.innerHTML = 'Compila bene il campo assegnato!';
        return;
    }
});
// per aggiungere un elemento nel JSON
async function addData(data: any): Promise<any> {
    let response = await fetch('http://localhost:3000/todo', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=utf-8',
        },
        body: JSON.stringify(data),
    })

}


async function elimina(item:any): Promise<any> {
    var answer = window.confirm("Sei sicuro?");
	if (answer) {
        try {
            let response = await fetch(`http://localhost:3000/todo/${item}`, {
                method: "DELETE",
            });
        } catch (err) {
        }
    }
}
